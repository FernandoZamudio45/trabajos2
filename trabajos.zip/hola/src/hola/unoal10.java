package hola;
import java.util.Scanner;
public class unoal10 {
	public static void main(String[] args)
	{
		for (int x=1; x<10; x++)
		{
			System.out.println("Hola -> "+x);		}
	}
}
