package hola;
import java.util.Scanner;
public class ejercicio {
	public static void main(String[] args)
	{
		String sex = "por favor";
		byte ed;
		double vel;
		int NE;
		int Hab;
		byte dient;
		byte herm;
		int us;
		int op;
		int din;
		int msg;
		int tweet;
		System.out.println(sex);
	}
}
