package hola;
import java.util.Scanner;
public class foranidados {
	public static void main(String[] args)
	{
		for (int x=1; x<=10; x++)
		{
			for (int y=1; y<=10; y++)
			{
				System.out.println("X: "+x+" Y: "+y);
			}
			
			}
	}
}
