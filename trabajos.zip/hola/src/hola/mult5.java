package hola;
import java.util.Scanner;
public class mult5 {
	public static void main(String[] args)
	{
		
		for (int i=1; i<11; i++)
		{
			int m= 5*i;
			System.out.println("5*"+i+" = "+m);
		}
	}
}
