package hola;
import java.util.Scanner;
public class unoalcien {
	public static void main(String[] args)
	{
		int x=1;
		while (x<101)
		{
			System.out.println(x);
			x++;
		}
		
	}
}
