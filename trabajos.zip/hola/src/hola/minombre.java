package hola;
import java.util.Scanner;
public class minombre {
	public static void main(String[] args)
	{
		String nom = "Fernando";
		System.out.println("Bienvenido "+nom);
	}
}
