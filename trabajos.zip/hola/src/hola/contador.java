package hola;

public class contador {

}
