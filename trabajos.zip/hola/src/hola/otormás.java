package hola;

public class otormás {
	//En las clases locales si se pueden duplicar los nombres de variables ;)
		 static int funcionalidad1(int v, int v2)
		{
			return v+v2;
		}
		 public static void main (String[] args) throws Exception
		 {
			int v = funcionalidad1(8,5);
			System.out.println(v);
		 }
	}

